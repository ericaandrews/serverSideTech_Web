﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Builder;

namespace HomeworkTwo.Models
{
    public class Person
    {
        [Required]
        public String memberIdOne { get; set; }
        [Required]
        public String memberNameOne { get; set; }
        [Required]
        [Range(18, 65)]
        public String memberAgeOne { get; set; }
        [Required(ErrorMessage = "Your must provide a PhoneNumber")]
        [DataType(DataType.PhoneNumber)]
        [RegularExpression(@"^\(?([0-9]{3})\)?[-. ]?([0-9]{3})[-. ]?([0-9]{4})$", ErrorMessage = "Not a valid Phone number")]
        public String memberTelephoneOne { get; set; }

        [Required]
        public String memberIdTwo { get; set; }
        [Required]
        public String memberNameTwo { get; set; }
        [Required]
        [Range(18, 65)]
        public String memberAgeTwo { get; set; }
        [Required(ErrorMessage = "Your must provide a PhoneNumber")]
        [DataType(DataType.PhoneNumber)]
        [RegularExpression(@"^\(?([0-9]{3})\)?[-. ]?([0-9]{3})[-. ]?([0-9]{4})$", ErrorMessage = "Not a valid Phone number")]
        public String memberTelephoneTwo { get; set; }

        [Required]
        public String memberIdThree { get; set; }
        [Required]
        public String memberNameThree { get; set; }
        [Required]
        [Range(18, 65)]
        public String memberAgeThree { get; set; }
        [Required(ErrorMessage = "Your must provide a PhoneNumber")]
        [DataType(DataType.PhoneNumber)]
        [RegularExpression(@"^\(?([0-9]{3})\)?[-. ]?([0-9]{3})[-. ]?([0-9]{4})$", ErrorMessage = "Not a valid Phone number")]
        public String memberTelephoneThree { get; set; }

        [Required]
        public String memberIdFour { get; set; }
        [Required]
        public String memberNameFour { get; set; }
        [Required]
        [Range(18, 65)]
        public String memberAgeFour { get; set; }
        [Required(ErrorMessage = "Your must provide a PhoneNumber")]
        [DataType(DataType.PhoneNumber)]
        [RegularExpression(@"^\(?([0-9]{3})\)?[-. ]?([0-9]{3})[-. ]?([0-9]{4})$", ErrorMessage = "Not a valid Phone number")]
        public String memberTelephoneFour { get; set; }

    }
}
