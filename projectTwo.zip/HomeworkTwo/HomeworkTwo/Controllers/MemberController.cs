﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using HomeworkTwo.Models;
using static Microsoft.EntityFrameworkCore.DbLoggerCategory;
using Microsoft.EntityFrameworkCore;
// For more information on enabling MVC for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace HomeworkTwo.Controllers
{
    public class MemberController : Controller
    {
        // GET: /<controller>/
        public IActionResult Index(Person person)
        {
            if (person.memberIdOne == null)
            {
                person.memberIdOne = "1";
            }
            if (person.memberNameOne == null)
            {
                person.memberNameOne = "David";
            }
            if (person.memberAgeOne == null)
            {
                person.memberAgeOne = "18";
            }
            if (person.memberTelephoneOne == null)
            {
                person.memberTelephoneOne = "(111) 111-1111";
            }
            else
            {
                person.memberNameOne = person.memberNameOne;
                person.memberAgeOne = person.memberAgeOne;
                person.memberTelephoneOne = person.memberTelephoneOne;
            }

            if (person.memberIdTwo == null)
            {
                person.memberIdTwo = "2";
            }
            if (person.memberNameTwo == null)
            {
                person.memberNameTwo = "Laura";
            }
            if (person.memberAgeTwo == null)
            {
                person.memberAgeTwo = "21";
            }
            if (person.memberTelephoneTwo == null)
            {
                person.memberTelephoneTwo = "(222) 222-2222";
            }
            else
            {
                person.memberNameTwo = person.memberNameTwo;
                person.memberAgeTwo = person.memberAgeTwo;
                person.memberTelephoneTwo = person.memberTelephoneTwo;
            }

            if (person.memberIdThree == null)
            {
                person.memberIdThree = "3";
            }
            if (person.memberNameThree == null)
            {
                person.memberNameThree = "Alex";
            }
            if (person.memberAgeThree == null)
            {
                person.memberAgeThree = "25";
            }
            if (person.memberTelephoneThree == null)
            {
                person.memberTelephoneThree = "(333) 333-3333";
            }
            else
            {
                person.memberNameThree = person.memberNameThree;
                person.memberAgeThree = person.memberAgeThree;
                person.memberTelephoneThree = person.memberTelephoneThree;
            }

            if (person.memberIdFour == null)
            {
                person.memberIdFour = "4";
            }
            if (person.memberNameFour == null)
            {
                person.memberNameFour = "Olivia";
            }
            if (person.memberAgeFour == null)
            {
                person.memberAgeFour = "20";
            }
            if (person.memberTelephoneFour == null)
            {
                person.memberTelephoneFour = "(444) 444-4444";
            }
            else
            {
                person.memberNameFour = person.memberNameFour;
                person.memberAgeFour = person.memberAgeFour;
                person.memberTelephoneFour = person.memberTelephoneFour;
            }

            return View(person);
        }

        public IActionResult EditMemberOne(Person person)
        {
            return View(person);
        }
        public IActionResult EditMemberTwo(Person person)
        {
            return View(person);
        }
        public IActionResult EditMemberThree(Person person)
        {
            return View(person);
        }
        public IActionResult EditMemberFour(Person person)
        {
            return View(person);
        }

        public IActionResult DetailsMemberOne(Person person)
        {
            person.memberIdOne = "1";
            person.memberNameOne = "David";
            person.memberAgeOne = "18";
            person.memberTelephoneOne = "(111) 111-1111";

            return View(person);
        }
        public IActionResult DetailsMemberTwo(Person person)
        {
            person.memberIdTwo = "2";
            person.memberNameTwo = "Laura";
            person.memberAgeTwo = "21";
            person.memberTelephoneTwo = "(222) 222-2222";

            return View(person);
        }
        public IActionResult DetailsMemberThree(Person person)
        {
            person.memberIdThree = "3";
            person.memberNameThree = "Alex";
            person.memberAgeThree = "25";
            person.memberTelephoneThree = "(333) 333-3333";

            return View(person);
        }
        public IActionResult DetailsMemberFour(Person person)
        {
            person.memberIdFour = "4";
            person.memberNameFour = "Olivia";
            person.memberAgeFour = "20";
            person.memberTelephoneFour = "(444) 444-4444";

            return View(person);
        }

        public IActionResult DeleteMemberOne(Person person)
        {
            person.memberIdOne = " ";
            person.memberNameOne = " ";
            person.memberAgeOne = " ";
            person.memberTelephoneOne = " ";

            person.memberIdTwo = "2";
            person.memberNameTwo = "Laura";
            person.memberAgeTwo = "21";
            person.memberTelephoneTwo = "(222) 222-2222";

            person.memberIdThree = "3";
            person.memberNameThree = "Alex";
            person.memberAgeThree = "25";
            person.memberTelephoneThree = "(333) 333-3333";

            person.memberIdFour = "4";
            person.memberNameFour = "Olivia";
            person.memberAgeFour = "20";
            person.memberTelephoneFour = "(444) 444-4444";

            return View("Index", person);
        }
        public IActionResult DeleteMemberTwo(Person person)
        {
            person.memberIdOne = "1";
            person.memberNameOne = "David";
            person.memberAgeOne = "18";
            person.memberTelephoneOne = "(111) 111-1111";

            person.memberIdTwo = " ";
            person.memberNameTwo = " ";
            person.memberAgeTwo = " ";
            person.memberTelephoneTwo = " ";

            person.memberIdThree = "3";
            person.memberNameThree = "Alex";
            person.memberAgeThree = "25";
            person.memberTelephoneThree = "(333) 333-3333";

            person.memberIdFour = "4";
            person.memberNameFour = "Olivia";
            person.memberAgeFour = "20";
            person.memberTelephoneFour = "(444) 444-4444";

            return View("Index", person);
        }
        public IActionResult DeleteMemberThree(Person person)
        {
            person.memberIdOne = "1";
            person.memberNameOne = "David";
            person.memberAgeOne = "18";
            person.memberTelephoneOne = "(111) 111-1111";

            person.memberIdTwo = "2";
            person.memberNameTwo = "Laura";
            person.memberAgeTwo = "21";
            person.memberTelephoneTwo = "(222) 222-2222";

            person.memberIdThree = " ";
            person.memberNameThree = " ";
            person.memberAgeThree = " ";
            person.memberTelephoneThree = " ";

            person.memberIdFour = "4";
            person.memberNameFour = "Olivia";
            person.memberAgeFour = "20";
            person.memberTelephoneFour = "(444) 444-4444";

            return View("Index", person);
        }
        public IActionResult DeleteMemberFour(Person person)
        {
            person.memberIdOne = "1";
            person.memberNameOne = "David";
            person.memberAgeOne = "18";
            person.memberTelephoneOne = "(111) 111-1111";

            person.memberIdTwo = "2";
            person.memberNameTwo = "Laura";
            person.memberAgeTwo = "21";
            person.memberTelephoneTwo = "(222) 222-2222";

            person.memberIdThree = "3";
            person.memberNameThree = "Alex";
            person.memberAgeThree = "25";
            person.memberTelephoneThree = "(333) 333-3333";

            person.memberIdFour = " ";
            person.memberNameFour = " ";
            person.memberAgeFour = " ";
            person.memberTelephoneFour = " ";

            return View("Index", person);
        }
    }
}
