﻿using System;

namespace newApp
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Type your name below: ");
            var name = Console.ReadLine();

            string amORpm = DateTime.Now.ToString("tt");
            string am = "AM";
            string pm = "PM";

            if (amORpm == am)
            {
                Console.WriteLine("Good morning, " + name + "! It is now " + DateTime.Now.ToString("M/dd/yyyy H:mm:ss tt"));
            }
            if(amORpm == pm)
            {
                Console.WriteLine("Good afternoon, " + name + "! It is now " + DateTime.Now.ToString("M/dd/yyyy H:mm:ss tt"));
            }
        }
    }
}


