﻿using System;
using System.Web;
using System.Web.UI;

namespace Homework1
{
    public partial class Default : System.Web.UI.Page
    {
        public void Button1Clicked(object sender, EventArgs args)
        {
            Label1.Style.Add("visibility", "hidden");
            TextBox1.Style.Add("visibility", "hidden");
            DropDownList1.Style.Add("visibility", "hidden");
            Button1.Style.Add("visibility", "hidden");
            Label2.Text = "Dear " + TextBox1.Text + ", it seems that you prefer to receive information in " + DropDownList1.Text + ".";
        }
        public void Page_Load(object sender, EventArgs args)
        {
            Label1.Text = "This is the page for my Homework 1. Today is " + DateTime.Now.ToString() + "."; 
        }
    }
}
