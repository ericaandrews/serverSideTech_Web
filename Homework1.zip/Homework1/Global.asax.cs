﻿using System.Web;

namespace Homework1
{
    public class Global : HttpApplication
    {
        protected void Application_Start()
        {
        }
    }
}
