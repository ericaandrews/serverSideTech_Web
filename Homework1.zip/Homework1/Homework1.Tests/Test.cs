﻿using NUnit.Framework;
using System;

namespace Homework1.Tests
{
    [TestFixture]
    public class Test
    {
        [Test]
        public void TestCase()
        {
        }
    }
}
